package com.Round2.PIPRound2Application.repository;

import com.Round2.PIPRound2Application.entities.TableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.persistence.NamedNativeQuery;

public interface TableRepository extends JpaRepository<TableEntity,Integer> {
  @Query(value = " Select * from table_details where table_type_table_type_id in " +
            " (select table_type_id from table_type_details where table_type >=:requirement ) " +
            " and status = 'V' order by table_type_table_type_id limit 1",nativeQuery = true)
    TableEntity findTableIdBasedOnRequiredSeats(int requirement);

}
