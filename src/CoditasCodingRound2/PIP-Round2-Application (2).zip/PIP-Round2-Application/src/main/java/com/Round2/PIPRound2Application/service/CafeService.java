package com.Round2.PIPRound2Application.service;
import com.Round2.PIPRound2Application.entities.BookingEntity;
import com.Round2.PIPRound2Application.entities.MenuEntity;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface CafeService {
    BookingEntity addBooking(BookingEntity booking);
    List<MenuEntity> showMenuOfItem();
}
