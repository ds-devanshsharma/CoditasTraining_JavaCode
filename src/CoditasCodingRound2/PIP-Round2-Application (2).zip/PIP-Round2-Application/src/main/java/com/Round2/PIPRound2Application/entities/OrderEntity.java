package com.Round2.PIPRound2Application.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "Order_")
public class OrderEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;
    @ManyToOne
    private BookingEntity booking;
    @ManyToMany
    private List<MenuEntity> menu ;
}
