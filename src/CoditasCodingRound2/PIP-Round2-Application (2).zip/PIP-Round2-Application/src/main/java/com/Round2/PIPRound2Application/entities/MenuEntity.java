package com.Round2.PIPRound2Application.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "Menu_Details")
public class MenuEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int  serialId;
    @Column(nullable = false)
    private double price;
    @ManyToMany(mappedBy = "menu")
    private List<OrderEntity> order;
}
