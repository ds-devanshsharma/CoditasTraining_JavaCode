package com.Round2.PIPRound2Application.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "Table_type_details")
public class TableTypeEntity {
    @Id
    private int tableTypeId;
    @Column(nullable = false)
    private int tableType;
    @Column(nullable = false)
    private int countOfAvailableTable;
    @JsonManagedReference
    @OneToMany(mappedBy = "tableType")
    private List<TableEntity> tableList;
}
