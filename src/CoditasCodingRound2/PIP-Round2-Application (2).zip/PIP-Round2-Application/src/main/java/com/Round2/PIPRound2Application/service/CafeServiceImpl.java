package com.Round2.PIPRound2Application.service;


import com.Round2.PIPRound2Application.entities.BookingEntity;
import com.Round2.PIPRound2Application.entities.MenuEntity;
import com.Round2.PIPRound2Application.entities.TableEntity;
import com.Round2.PIPRound2Application.repository.BookingRepository;
import com.Round2.PIPRound2Application.repository.CafeRepository;
import com.Round2.PIPRound2Application.repository.MenuRepository;
import com.Round2.PIPRound2Application.repository.TableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

@Service
public class CafeServiceImpl implements CafeService{
    @Autowired
    CafeRepository cafeRepository ;
    @Autowired
    MenuRepository menuRepository ;
    @Autowired
    TableRepository tableRepository;
    @Autowired
    BookingRepository bookingRepository;

    @Override
    public BookingEntity addBooking(BookingEntity booking) {
        TableEntity table =null ;
        if(booking.getReqSeat()<=8) {
            table = tableRepository.findTableIdBasedOnRequiredSeats(booking.getBookingId());
            System.out.println(table.getTableId());
        }
        else{
        }
        booking.setTable(table);
        return bookingRepository.save(booking);
    }

    @Override
    public List<MenuEntity> showMenuOfItem() {
        return menuRepository.findAll();
    }
}
