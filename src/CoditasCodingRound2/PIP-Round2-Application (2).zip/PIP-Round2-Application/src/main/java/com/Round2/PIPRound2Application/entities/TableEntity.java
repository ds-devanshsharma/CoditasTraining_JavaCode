package com.Round2.PIPRound2Application.entities;

import lombok.Data;

import javax.persistence.*;

@Entity

@Table(name = "Table_details")
public class TableEntity {
    @Id
    private int tableId;
    @Column(nullable = false)
    private String status;
    @ManyToOne
    @JoinColumn(name = "tableTypeId")
    private TableTypeEntity tableType;

    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
