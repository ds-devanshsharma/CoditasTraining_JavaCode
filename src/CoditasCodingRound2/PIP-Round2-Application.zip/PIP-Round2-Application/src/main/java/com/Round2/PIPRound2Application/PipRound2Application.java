package com.Round2.PIPRound2Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PipRound2Application {

	public static void main(String[] args) {
		SpringApplication.run(PipRound2Application.class, args);
	}

}
