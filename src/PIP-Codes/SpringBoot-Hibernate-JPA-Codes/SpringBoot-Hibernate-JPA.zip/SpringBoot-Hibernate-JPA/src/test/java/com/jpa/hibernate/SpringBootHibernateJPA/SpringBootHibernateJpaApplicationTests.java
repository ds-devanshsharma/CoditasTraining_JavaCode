package com.jpa.hibernate.SpringBootHibernateJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHibernateJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
