package com.jpa.hibernate.SpringBootHibernateJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHibernateJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHibernateJpaApplication.class, args);
	}

}
