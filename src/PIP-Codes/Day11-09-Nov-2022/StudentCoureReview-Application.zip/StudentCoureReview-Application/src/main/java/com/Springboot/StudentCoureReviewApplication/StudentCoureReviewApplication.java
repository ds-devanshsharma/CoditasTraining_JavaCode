package com.Springboot.StudentCoureReviewApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCoureReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentCoureReviewApplication.class, args);
	}

}
