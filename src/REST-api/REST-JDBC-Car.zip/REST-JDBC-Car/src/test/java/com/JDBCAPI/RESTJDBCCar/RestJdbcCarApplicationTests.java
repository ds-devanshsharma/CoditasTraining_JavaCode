package com.JDBCAPI.RESTJDBCCar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestJdbcCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
