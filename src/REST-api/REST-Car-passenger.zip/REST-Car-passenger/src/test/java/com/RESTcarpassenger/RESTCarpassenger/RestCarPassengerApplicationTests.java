package com.RESTcarpassenger.RESTCarpassenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCarPassengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
