package com.ToolManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToolManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
