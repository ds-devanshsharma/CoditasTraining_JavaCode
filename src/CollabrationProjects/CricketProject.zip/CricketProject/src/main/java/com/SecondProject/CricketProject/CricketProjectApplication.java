package com.SecondProject.CricketProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricketProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketProjectApplication.class, args);
	}

}
