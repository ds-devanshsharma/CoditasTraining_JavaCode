package com.SpringPrimitiveproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPrimitiveProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPrimitiveProjectApplication.class, args);
	}

}
