package com.SpringPrimitiveproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPrimitiveProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
