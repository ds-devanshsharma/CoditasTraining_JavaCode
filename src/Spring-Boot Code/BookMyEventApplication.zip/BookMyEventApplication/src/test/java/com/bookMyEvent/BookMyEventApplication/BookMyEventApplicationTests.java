package com.bookMyEvent.BookMyEventApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyEventApplicationTests {

	@Test
	void contextLoads() {
	}

}
