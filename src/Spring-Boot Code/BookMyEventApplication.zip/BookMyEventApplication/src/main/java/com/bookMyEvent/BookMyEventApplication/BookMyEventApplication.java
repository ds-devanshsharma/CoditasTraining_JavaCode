package com.bookMyEvent.BookMyEventApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyEventApplication.class, args);
	}

}
